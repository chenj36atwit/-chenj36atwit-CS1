PA8 - Files
===========
A programming assignment, in two parts, to focus on terminal I/O, conditional tests, state variables, mathematical expressions, loops, methods, arrays, file I/O, and exceptions.
