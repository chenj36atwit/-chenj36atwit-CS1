LA4 - GCD
=========
A lab assignment, in one part, to focus on terminal I/O (including formatting), variables, mathematical expressions, conditional statements, and methods.
