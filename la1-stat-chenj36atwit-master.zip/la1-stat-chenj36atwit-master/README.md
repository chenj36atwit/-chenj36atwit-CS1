LA1 - Stats
===========
A lab assignment, in one part, to focus on terminal I/O (including formatting), variables, and mathematical expressions.