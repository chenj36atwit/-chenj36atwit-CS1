PA9 - Fraction Class
====================
A programming assignment, in one parts, to focus on terminal I/O, conditional tests, state variables, mathematical expressions, methods, arrays, and classes.
