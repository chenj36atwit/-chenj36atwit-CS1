package edu.wit.cs.comp1000;

// Jacky Chen 9/11/2021
//revisited on 9/15/201
public class PA0a {
	
	// print out Hello world
	public static void main(String[] args) {
		System.out.println("Hello World!");
	}

}
