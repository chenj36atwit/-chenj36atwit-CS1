PAO - Hello World
=================
First programming assignment to get accustomed to Eclipse, JUnit, Javadoc, and GitLab.

