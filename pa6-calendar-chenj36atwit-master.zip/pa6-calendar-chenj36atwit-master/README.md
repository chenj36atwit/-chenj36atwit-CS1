PA6 - Calendar
==============
A programming assignment, in one part, to focus on terminal I/O, conditional tests, state variables, mathematical expressions, loops, and methods.
